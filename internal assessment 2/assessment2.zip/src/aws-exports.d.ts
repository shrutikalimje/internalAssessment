declare const awsmobile: Record<string, any>;
export default awsmobile;
