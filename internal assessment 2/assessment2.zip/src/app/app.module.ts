import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AmplifyAuthenticatorModule } from '@aws-amplify/ui-angular';

/* new form imports */
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RestaurantsComponent } from './restaurants/restaurants.component';
import { AddComponent } from './component/add/add.component';
import { FetchComponent } from './component/fetch/fetch.component';
import { DeleteComponent } from './component/delete/delete.component';
import { UpdateComponent } from './component/update/update.component';
import { HomeComponent } from './component/home/home.component';

@NgModule({
  declarations: [AppComponent, RestaurantsComponent, AddComponent, FetchComponent, DeleteComponent, UpdateComponent, HomeComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AmplifyAuthenticatorModule,
    /* configuring form modules */
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
