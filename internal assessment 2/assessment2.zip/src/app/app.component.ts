import { Component, OnInit, OnDestroy } from '@angular/core';
import { ZenObservable } from 'zen-observable-ts';
import { Restaurant } from './API.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'amplify-app';

  // private subscription: ZenObservable.Subscription | null = null;
  // restaurants: any;
  // api: any;

  // async ngOnInit() {
  //   this.api.listRestaurants().then((event: { items: Restaurant[] }) => {
  //     this.restaurants = event.items as Restaurant[];
  //   });

  //   /* subscribe to new restaurants being created */
  //   this.subscription = this.api
  //     .OnCreateRestaurantListener()
  //     .subscribe((event: any) => {
  //       const newRestaurant = event.value.data.onCreateRestaurant;
  //       this.restaurants = [newRestaurant, ...this.restaurants];
  //     });
  // }

  // ngOnDestroy() {
  //   if (this.subscription) {
  //     this.subscription.unsubscribe();
  //   }
  //   this.subscription = null;
  // }
}
