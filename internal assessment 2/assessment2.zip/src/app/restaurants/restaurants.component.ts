import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { filter } from 'rxjs';
import { APIService, Restaurant } from '../API.service';

@Component({
  selector: 'app-restaurants',
  templateUrl: './restaurants.component.html',
  styleUrls: ['./restaurants.component.css'],
})
export class RestaurantsComponent implements OnInit {
  public createForm: FormGroup;
  // public updateForm: FormGroup;
  currentRestro!: Restaurant;
  searchText?: string;
  searchRes?: any;
  ondelete?: any;
  oncreate?: any;
  onupdate?: any;

  /* declare restaurants variable */
  restaurants: any;

  constructor(private api: APIService, private fb: FormBuilder) {
    this.createForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      city: ['', Validators.required],
    });
  }

  async ngOnInit() {
    /* fetch restaurants when app loads */
    this.api.ListRestaurants().then((event) => {
      this.restaurants = event.items;
      console.log(event);
    });
  }

  public onCreate(restaurant: Restaurant) {
    this.api
      .CreateRestaurant(restaurant)
      .then((event) => {
        console.log('item created!');
        this.createForm.reset();
      })
      .catch((e) => {
        console.log('error creating restaurant...', e);
      });
  }
  id: string = '';
  setupdateid(id: string) {
    this.id = id;
  }

  public onUpdate(restaurant: any) {
    // console.log('restaurant;', restaurant);
    this.api
      .UpdateRestaurant({
        id: this.id,
        name: restaurant.name,
        city: restaurant.city,
        description: restaurant.description,
      })
      .then((event) => {
        console.log('item update');
        console.log(event.id, event.name);
      })
      .catch((e) => {
        console.log('error in onUpdate in restro ..', e);
      });
  }

  public onDelete(restaurant: Restaurant) {
    this.api
      .DeleteRestaurant({ id: restaurant.id })
      .then((event) => {
        console.log('item delete');
        //fetch the list again after deleting
        // [{ query: this.api.ListRestaurants }];
      })
      .catch((e) => {
        console.log(
          'error deleting the restaurant in restaurant component..',
          e
        );
      });
  }

  public OnSearch() {
    this.api
      .SearchRestaurants({ city: { eq: this.searchText } })
      .then((event) => {
        this.searchRes = event.items;
        console.log(this.searchRes);
      })
      .catch((e) => {
        console.log('error in onSearch component ..' + e);
      });
  }

  deleteSub = this.api.OnDeleteRestaurantListener().subscribe((data) => {
    console.log(data);
    this.ondelete = data.value.data?.onDeleteRestaurant;
    this.restaurants = this.restaurants.filter(
      (x: any) => x.id != this.ondelete.id
    );
  });
  addSub = this.api.OnCreateRestaurantListener().subscribe((data) => {
    console.log(data);
    this.oncreate = data.value.data?.onCreateRestaurant;
    this.restaurants = [...this.restaurants, this.oncreate];
  });

  updatesub = this.api.OnUpdateRestaurantListener().subscribe((data) => {
    console.log(data);
    this.onupdate = data.value.data?.onUpdateRestaurant;
    this.restaurants = this.restaurants.filter(
      (x: any) => x.id != this.onupdate.id
    );
    this.restaurants = [...this.restaurants, this.onupdate];
  });
}
