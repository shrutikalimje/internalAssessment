import { Component, Output, Input, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css'],
})
export class UpdateComponent {
  @Input() restaurant!: any;
  @Output() OnUpdateId: EventEmitter<any> = new EventEmitter();

  restName: string = '';
  restDescript: string = '';
  restCity: string = '';
  // restId: string = '';

  // update() {
  //   console.log(this.restName);
  // }
}
