import { Component, EventEmitter, Input, Output, OnInit } from '@angular/core';
import { API } from 'aws-amplify';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css'],
})
export class DeleteComponent implements OnInit {
  @Input() restaurant!: any;
  @Output() OnDeleteId: EventEmitter<any> = new EventEmitter<any>();

  id: string = '';
  ngOnInit(): void {
    this.id = this.restaurant.id;
  }

  //   delete() {
  //     // this.OnDeleteId(){

  //     }
  //   }
}
