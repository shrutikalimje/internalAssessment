import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { Amplify, Auth } from 'aws-amplify';
import awsconfig from './aws-exports';

import aws_exports from './aws-exports';

platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch((err) => console.error(err));

Amplify.configure(aws_exports);
Auth.configure(awsconfig);
