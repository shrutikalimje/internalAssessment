/*const express = require("express");
const bodyParser = require("body-parser");
// const { ApolloServer, gql } = require("apollo-server-express");
const cors = require("cors");
const mongoose = require("mongoose");

const { graphqlHTTP } = require("express-graphql");
const graphqlSchema = require("./graphql/schema");
const graphqlResolver = require("./graphql/resolver");

// const server = new ApolloServer({ graphqlSchema, graphqlResolver });

const app = express();

app.use(bodyParser.json);
app.use(cors());
app.use(
  "/graphql",
  //   "/graphiql",
  graphqlHTTP({
    schema: graphqlSchema,
    rootValue: graphqlResolver,
    graphiql: true,
  })
);
const dbConfig = require("./config/database.config");
mongoose.Promise = global.Promise;

mongoose
  .connect(dbConfig.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("successfully connected");

    // app.listen(4000, () => {
    //   console.log("server is listening on port :4000");
    // });
  })

  .catch((err) => {
    console.log("could not connect", err);
    process.exit();
  });

app.listen(4000, () => {
  console.log("server is listening on port :4000");
});


*/
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const cors = require("cors");

const { graphqlHTTP } = require("express-graphql");

const graphqlSchema = require("./graphql/schema");
const graphqlResolver = require("./graphql/resolver");
const app = express();

app.use(bodyParser.json());

app.use(cors());

app.use(
  "/graphql",
  graphqlHTTP({
    schema: graphqlSchema,
    rootValue: graphqlResolver,
    graphiql: true,
  })
);

const dbConfig = require("./config/database.config.js");

mongoose.Promise = global.Promise;

mongoose
  .connect(dbConfig.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log("Successfully connected to the database");
  })
  .catch((err) => {
    console.log("Could not connect to the database. Exiting now...", err);
    process.exit();
  });

app.listen(4500, () => {
  console.log("Server is listening on port 4500");
});
