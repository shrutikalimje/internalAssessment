const { buildSchema } = require("graphql");
module.exports = buildSchema(`
    type Book{
        _id:ID!
        book:String!
        author:String!
    }
    type BookData{
        books:[Book!]!
    }
    input BookInputData{
        book:String!
        author:String!
    }
    type RootQuery{
        books:BookData!
    }

    type RootMutation{
        createBook(bookInput:BookInputData):Book!
        updateBook(id:ID! , bookInput:BookInputData):Book!
        deleteBook(id:ID!):Book!
    }
    schema{
        query:RootQuery
        mutation:RootMutation
    }
`);
