const Book = require("../models/book");

module.exports = {
  books: async function () {
    const books = await Book.find();
    return {
      books: books.map((b) => {
        return {
          ...b._doc,
          _id: b._id.toString(),
        };
      }),
    };
  },

  createBook: async function ({ bookInput }) {
    const book = new Book({
      book: bookInput.book,
      author: bookInput.author,
    });
    const createdBook = await book.save();
    return {
      ...createdBook._doc,
      _id: createdBook._id.toString(),
    };
  },
  updateBook: async function ({ id, bookInput }) {
    const book = await Book.findById(id);
    if (!book) {
      throw new Error("No book found!");
    }
    book.book = bookInput.book;
    book.author = bookInput.author;
    const updateBook = await book.save();
    return {
      ...updateBook._doc,
    };
  },
  deleteBook: async function ({ id }) {
    const book = await Book.findById(id);
    if (!book) {
      throw new Error("No book found!");
    }
    await Book.findByIdAndRemove(id);
    return {
      ...book._doc,
      _id: book._id.toString(),
    };
  },
};
