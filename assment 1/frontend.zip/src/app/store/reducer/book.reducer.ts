import { createReducer, on } from '@ngrx/store';
import { from } from 'rxjs';
import { Book } from 'src/app/model/book.model';
import {
  addBook,
  deleteBook,
  updateBook,
  fetchBook,
} from '../action/book.action';

export interface BookState {
  books: Book[];
}

const initialState: BookState = {
  books: [],
};

const _bookReducer = createReducer(
  initialState,
  on(fetchBook, (state, { books }) => {
    return {
      ...state,
      book: books,
    };
  }),
  on(addBook, (state, { book }) => {
    return {
      ...state,
      books: [...state.books, book],
    };
  }),
  on(updateBook, (state, { id, book }) => {
    return {
      ...state,
      books: state.books.map((b) => (b.id == id ? book : b)),
    };
  }),
  on(deleteBook, (state, { id }) => {
    return {
      ...state,
      books: state.books.filter((b) => b.id != id),
    };
  })
);

export const bookReducer = (state: any, action: any) => {
  return _bookReducer(state, action);
};
