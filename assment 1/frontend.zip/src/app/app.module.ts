import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Apollo, ApolloModule } from 'apollo-angular';
import { AppRoutingModule } from './app-routing.module';
import { GraphQLModule } from './graphql.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { AddModalComponent } from './component/add-modal/add-modal.component';
import { HomeComponent } from './component/home/home.component';
import { UpdateModalComponent } from './component/update-modal/update-modal.component';
import { FormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { bookReducer } from './store/reducer/book.reducer';

@NgModule({
  declarations: [
    AppComponent,
    AddModalComponent,
    HomeComponent,
    UpdateModalComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    GraphQLModule,
    HttpClientModule,
    StoreModule.forRoot({ book: bookReducer }),
    ApolloModule,
  ],
  providers: [Apollo],
  bootstrap: [AppComponent],
})
export class AppModule {}
