import { Injectable } from '@angular/core';
import { Apollo } from 'apollo-angular';
import { from } from 'rxjs';
import {
  GET_BOOKS,
  CREATE_BOOK,
  DELETE_BOOK,
  UPDATE_BOOK,
} from '../app.component';
import { Observable, map } from 'rxjs';
import { Book } from '../model/book.model';
@Injectable({
  providedIn: 'root',
})
export class BookService {
  constructor(private apollo: Apollo) {}

  listTodos(): Observable<Book[]> {
    return this.apollo.query({ query: GET_BOOKS }).pipe(
      map((result: any) => {
        return result.data.todos;
      })
    );
  }

  addBook(reqBody: Book): Observable<Book> {
    return this.apollo
      .mutate({
        mutation: CREATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          input: reqBody,
        },
      })
      .pipe(
        map((result: any) => {
          console.log(result.data.addBook);
          return result.data.addBook;
        })
      );
  }

  updateBook(reqBody: Book): Observable<Book> {
    return this.apollo
      .mutate({
        mutation: UPDATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          // id:id,
          input: reqBody,
        },
      })
      .pipe(
        map((result: any) => {
          console.log(result.data.updateBook);
          return result.data.updateBook;
        })
      );
  }

  deleteBook(id: String): Observable<Book> {
    return this.apollo
      .mutate({
        mutation: DELETE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: id,
        },
      })
      .pipe(
        map((result: any) => {
          console.log(id);
          return result.data.deleteBook;
        })
      );
  }
}
