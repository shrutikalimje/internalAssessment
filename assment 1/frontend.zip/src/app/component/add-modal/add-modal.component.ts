import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BookService } from 'src/app/service/book.service';
@Component({
  selector: 'app-add-modal',
  templateUrl: './add-modal.component.html',
  styleUrls: ['./add-modal.component.css'],
})
export class AddModalComponent {
  @Output() onCreate: EventEmitter<any> = new EventEmitter();
  bookName: String = '';
  authorName: String = '';

  create() {
    this.onCreate.emit({
      book: this.bookName,
      author: this.authorName,
    });
  }
}
