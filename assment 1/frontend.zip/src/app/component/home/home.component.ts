import { Component, OnInit } from '@angular/core';
import { Apollo } from 'apollo-angular';
import gql from 'graphql-tag';
import { AddModalComponent } from '../add-modal/add-modal.component';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { addBook, deleteBook } from 'src/app/store/action/book.action';
import { Book } from 'src/app/model/book.model';
const GET_BOOKS = gql`
  {
    books {
      books {
        _id
        book
        author
      }
    }
  }
`;

const CREATE_BOOK = gql`
  mutation createBook($book: String!, $author: String!) {
    createBook(bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;

const DELETE_BOOK = gql`
  mutation deleteBook($id: ID!) {
    deleteBook(id: $id) {
      _id
      book
      author
    }
  }
`;

const UPDATE_BOOK = gql`
  mutation updateBook($id: ID!, $book: String!, $author: String!) {
    updateBook(id: $id, bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  books!: any;

  constructor(private apollo: Apollo, private store: Store) {}

  ngOnInit() {
    this.apollo
      .watchQuery({
        query: GET_BOOKS,
      })
      .valueChanges.pipe(
        map((result: any) => {
          console.log(result.data.books.books);
          return result.data.books.books;
        })
      )
      .subscribe((data) => {
        this.books = data;
      });
  }

  create(payload: { book: string; author: string }) {
    const { book, author } = payload;
    this.apollo
      .mutate({
        mutation: CREATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          book: book,
          author: author,
        },
      })
      .subscribe((value: any) => {
        console.log('created', value.data.createBook);
        this.store.dispatch(addBook({ book: value }));
      });
  }

  delete(id: string) {
    console.log(id);
    this.apollo
      .mutate({
        mutation: DELETE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: id,
        },
      })
      .subscribe((value: any) => {
        console.log('deleted', id);
        this.store.dispatch(deleteBook({ id }));
      });
  }
  current_id: string = '';
  update1(_id: string) {
    console.log('inside on click update ' + _id);
    this.current_id = _id;
    return _id;
  }

  update(event: { id: string; book: string; author: string }) {
    const { id, book, author } = event;
    this.apollo
      .mutate({
        mutation: UPDATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: this.current_id,
          book: book,
          author: author,
        },
      })
      .subscribe(() => {
        console.log('updated');
      });
  }
}
