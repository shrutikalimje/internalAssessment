import { Component, OnInit } from '@angular/core';
import { Apollo } from 'apollo-angular';
import gql from 'graphql-tag';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export const GET_BOOKS = gql`
  {
    books {
      books {
        _id
        book
        author
      }
    }
  }
`;

export const CREATE_BOOK = gql`
  mutation createBook($book: String!, $author: String!) {
    createBook(bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;

export const DELETE_BOOK = gql`
  mutation deleteBook($id: ID!) {
    deleteBook(id: $id) {
      _id
      book
      author
    }
  }
`;

export const UPDATE_BOOK = gql`
  mutation updateBook($id: ID!, $book: String!, $author: String!) {
    updateBook(id: $id, bookInput: { book: $book, author: $author }) {
      _id
      book
      author
    }
  }
`;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Crud';

  books!: Observable<any>;

  constructor(private apollo: Apollo) {}

  ngOnInit() {
    this.books = this.apollo
      .watchQuery({
        query: GET_BOOKS,
      })
      .valueChanges.pipe(
        map((result: any) => {
          console.log(result.data.books.books);
          return result.data.books.books;
        })
      );
  }

  create(book: String, author: String) {
    this.apollo
      .mutate({
        mutation: CREATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          book: book,
          author: author,
        },
      })
      .subscribe(() => {
        console.log('created');
      });
  }

  delete(id: string) {
    console.log(id);
    this.apollo
      .mutate({
        mutation: DELETE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: id,
        },
      })
      .subscribe(() => {
        console.log('deleted');
      });
  }

  update(event: { id: string; book: string; author: string }) {
    const { id, book, author } = event;
    console.log(id, book, author);
    this.apollo
      .mutate({
        mutation: UPDATE_BOOK,
        refetchQueries: [{ query: GET_BOOKS }],
        variables: {
          id: id,
          book: book,
          author: author,
        },
      })
      .subscribe(() => {
        console.log('updated id:');
      });
  }
}
